// iOS: Web Audio is muted when the phone's silent switch is on, unless the page is also playing an
// <audio> element. Looping an inaudible clip switches the audio session to "playback" so the music plays.
(() => {
  const rate = 8000, n = rate; // 1 second of silence, 8-bit mono
  const buf = new ArrayBuffer(44 + n), v = new DataView(buf);
  const w = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  w(0, 'RIFF'); v.setUint32(4, 36 + n, true); w(8, 'WAVE'); w(12, 'fmt ');
  v.setUint32(16, 16, true); v.setUint16(20, 1, true); v.setUint16(22, 1, true);
  v.setUint32(24, rate, true); v.setUint32(28, rate, true); v.setUint16(32, 1, true); v.setUint16(34, 8, true);
  w(36, 'data'); v.setUint32(40, n, true);
  new Uint8Array(buf, 44).fill(128);
  const a = new Audio(URL.createObjectURL(new Blob([buf], { type: 'audio/wav' })));
  a.loop = true; a.volume = 0.01; a.setAttribute('playsinline', '');
  const go = () => { a.play().catch(() => {}); };
  ['pointerdown', 'touchend', 'click', 'keydown'].forEach((t) =>
    window.addEventListener(t, go, { once: true, passive: true }));
  document.addEventListener('visibilitychange', () => { if (!document.hidden) go(); });
})();

