// Floating virtual joystick (FPS-style) on the left side of the screen.
// Drag the thumb: left/right = steer the boat, up = speed up, down = slow down.
// The rest of the screen still rotates the camera (swipe) and zooms (pinch).
// It sends the same A/D/W/S key events the game already listens to. Hidden on mouse devices.
if (window.matchMedia('(pointer: coarse)').matches) {
  const R = 60;          // joystick radius (px)
  const DEAD = 0.3;      // dead zone (0..1)

  const css = document.createElement('style');
  css.textContent = `
    #joyzone { position: fixed; left: 0; bottom: 0; width: 38vw; height: 72vh; z-index: 2;
               touch-action: none; user-select: none; -webkit-user-select: none; }
    #joybase { position: fixed; z-index: 2; width: ${R * 2}px; height: ${R * 2}px; border-radius: 50%;
               border: 2px solid rgba(255,243,234,.35); background: rgba(11,10,13,.28);
               backdrop-filter: blur(4px); -webkit-backdrop-filter: blur(4px);
               opacity: .55; pointer-events: none; transition: opacity .2s; }
    #joybase.on { opacity: 1; }
    #joystick { position: absolute; left: 50%; top: 50%; width: 56px; height: 56px; margin: -28px 0 0 -28px;
                border-radius: 50%; background: rgba(255,243,234,.55); border: 1px solid rgba(255,243,234,.9); }
    #joybase.on #joystick { background: rgba(200,64,42,.8); }
  `;
  document.head.appendChild(css);

  const zone = document.createElement('div'); zone.id = 'joyzone';
  const base = document.createElement('div'); base.id = 'joybase';
  const stick = document.createElement('div'); stick.id = 'joystick';
  base.appendChild(stick);
  document.body.append(zone, base);

  const home = () => ({
    x: Math.max(R + 28, 0) + (parseInt(getComputedStyle(document.documentElement).getPropertyValue('--sal')) || 0) + 30,
    y: window.innerHeight - R - 34,
  });
  const place = (cx, cy) => { base.style.left = cx - R + 'px'; base.style.top = cy - R + 'px'; };
  const reset = () => { const h = home(); place(h.x, h.y); stick.style.transform = ''; };
  reset();
  window.addEventListener('resize', () => { if (!active) reset(); });

  const down = new Set();
  const key = (code, on) => {
    if (on === down.has(code)) return;
    on ? down.add(code) : down.delete(code);
    window.dispatchEvent(new KeyboardEvent(on ? 'keydown' : 'keyup', { code, bubbles: true }));
  };
  const release = () => ['KeyA', 'KeyD', 'KeyW', 'KeyS'].forEach((c) => key(c, false));

  let active = null, cx = 0, cy = 0;

  zone.addEventListener('pointerdown', (e) => {
    if (active !== null) return;
    active = e.pointerId;
    zone.setPointerCapture(e.pointerId);
    cx = Math.min(Math.max(e.clientX, R + 10), window.innerWidth * 0.38 - 10);
    cy = Math.min(e.clientY, window.innerHeight - R - 10);
    place(cx, cy);
    base.classList.add('on');
    move(e);
  });

  function move(e) {
    let dx = e.clientX - cx, dy = e.clientY - cy;
    const d = Math.hypot(dx, dy);
    if (d > R) { dx *= R / d; dy *= R / d; }
    stick.style.transform = `translate(${dx}px, ${dy}px)`;
    const nx = dx / R, ny = dy / R;
    key('KeyD', nx > DEAD);
    key('KeyA', nx < -DEAD);
    key('KeyS', ny > DEAD);
    key('KeyW', ny < -DEAD);
  }

  zone.addEventListener('pointermove', (e) => { if (e.pointerId === active) move(e); });
  const end = (e) => {
    if (e.pointerId !== active) return;
    active = null;
    base.classList.remove('on');
    release();
    reset();
  };
  zone.addEventListener('pointerup', end);
  zone.addEventListener('pointercancel', end);
  zone.addEventListener('contextmenu', (e) => e.preventDefault());
}

